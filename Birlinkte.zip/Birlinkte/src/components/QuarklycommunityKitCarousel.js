import Carousel from "@quarkly/community-kit/Carousel";
export default Carousel;